# Cookie Clicker Hacks
<p align="center">Um app do Cookie Clicker para desktop com adição de alguns hacks </p>

![Windows Screen](assets/windowsScreen.png)

## Hacks

![Windows Screen](assets/windowsTray.png)
> Os hacks podem ser ativados e desativados pelo menu na barra do Windows

  Os hacks adicionados são:
  - Mutar Áudio
  - Click infinito
  - Click no golden cookie automático

---
# Author
<a href="https://github.com/Leandro-Goncalves/">
  <img
    width="150px"
    src="https://github.com/Leandro-Goncalves.png"
    alt="Leandro Goncalves"
  />
 <br />
 <sub><b>Leandro Gonçalves</b></sub></a>

---