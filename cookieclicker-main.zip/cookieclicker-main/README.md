# Cookie-Clicker-2.031-Source- Modded by Par
Here is the Cookie Clicker 2.031 Source Code, modified; courtesy of this Par dude. <br>
Credit:https://orteil.dashnet.org/cookieclicker<br>
###### Version 2.031
###### (Updated version with the bank minigame and new tower that starts with an 'i' !)
----
